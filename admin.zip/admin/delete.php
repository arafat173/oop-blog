<?php
 require_once '../vendor/autoload.php';
 use App\classes\Category; 
 use App\classes\Blog; 

if(isset($_GET['cat'])){
    $id = $_GET['id'];
    Category::delete($id);
    header('Location:manage-category.php');


}
if(isset($_GET['blog'])){
    $id = $_GET['id'];
    Blog::delete($id);
    header('Location:manage-blog.php');


}



?>