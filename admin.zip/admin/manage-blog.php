<?php 
require_once 'header.php'; 
?>

<?php 
 require_once 'header.php'; 
 require_once '../vendor/autoload.php';
 use App\classes\Blog; 

 $allPost = Blog::allBlog();

 
 ?>
<div class="row">
                        <div class="col-sm-12">
                            <section class="card">
                                <header class="card-header">
                                    All Blog Post
                                    <span class="tools pull-right">
                                        <a href="javascript:;" class="fa fa-chevron-down"></a>
                                        <a href="javascript:;" class="fa fa-times"></a>
                                    </span>
                                </header>
                                <div class="card-body">
                                    <div class="adv-table">
                                        <table  class="display table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <td>Sl No</td>
                                                    <td>Category Name</td>
                                                    <td>Title</td>
                                                    <td>Content</td>
                                                    <td>Photo</td>
                                                    <td>Status</td>
                                                    <td style="width:250px" >Action</td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php 
                                            $sl=1;
                                            while($row=mysqli_fetch_assoc($allPost)) { 
                                            ?>
                                                <tr>
                                                    <td><?= $sl;?></td>
                                                    <td><?= $row['category_name'] ?></td>
                                                    <td><?= $row['title'] ?></td>
                                                    <td><?= $row['content'] ?></td>
                                                    <td><img style="width:50px" src="../uploads/<?= $row['photo'] ?>" alt=""></td>
                                                    <td>
                                                    <?php
                                                        if($row['status']==1) {
                                                    ?>
                                                      <a href="status.php?id=<?=$row['id']?>&blog=blog&inactive=inactive"class="btn btn-info btn-sm"><i class="fa fa-arrow-down">Active</i></a>

                                                    <?php
                                                 }
                                                 else{ 
                                                 ?>
                                                        <a href="status.php?id=<?=$row['id']?>&blog=blog&active=active"class="btn btn-warning btn-sm"><i class="fa fa-arrow-up">Inctive</i></a>
                                                 <?php } ?>
                                                    </td>
                                                    <td>
                                            
                                                        <a href="edit-blog.php?id=<?=$row['id'] ?>" class="btn btn-warning btn-sm"><i class="fa fa-pencil-square-o">Edit</i></a>
                                                        <a href="delete.php?id=<?=$row['id'] ?>&blog=blog"class="btn btn-danger btn-sm "><i class="fa fa-trash-o">Delete</i></a>
                                                    </td>
                                                </tr>
                                                 <?php
                                                 $sl++;
                                                 } 
                                                 ?>
                                            </tbody>

                                        </table>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
<?php require_once 'footer.php'; ?>
