<?php
 require_once '../vendor/autoload.php';
 use App\classes\Category; 
 use App\classes\Blog; 


 if(isset($_GET['active']) && isset($_GET['cat'])){
    $id = $_GET['id'];
    Category::active($id);
    header('Location:manage-category.php');
}
if(isset($_GET['inactive']) && isset($_GET['cat'])){
    $id = $_GET['id'];
    Category::inactive($id);
    header('Location:manage-category.php');

}
 if(isset($_GET['active']) && isset($_GET['blog'])){
    $id = $_GET['id'];
    Blog::active($id);
    header('Location:manage-blog.php');
}
if(isset($_GET['inactive']) && isset($_GET['blog'])){
    $id = $_GET['id'];
    Blog::inactive($id);
    header('Location:manage-blog.php');

}

?>